import React from "react";
import "../footer/footer.css";

const Footer = () => {
  return <div className="absolute-center">Made with ❤️ by Vedant Yetekar</div>;
};

export default Footer;
